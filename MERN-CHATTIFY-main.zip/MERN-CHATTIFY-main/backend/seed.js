import { seedDatabase } from './src/seeds/user.seed.js';

seedDatabase(); 